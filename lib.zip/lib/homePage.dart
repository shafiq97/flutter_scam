import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_image_slideshow/flutter_image_slideshow.dart';
import 'package:fraudrader/addbankfraud.dart';
import 'package:fraudrader/addphonefraud.dart';
import 'package:fraudrader/appDrawer.dart';
import 'package:fraudrader/bankFrauds.dart';
import 'package:fraudrader/phonedetailscreen.dart';
import 'package:fraudrader/mobilefrauds.dart';

class HomeAct extends StatefulWidget {
  @override
  _HomeActState createState() => _HomeActState();
}

class _HomeActState extends State<HomeAct> with SingleTickerProviderStateMixin {
  TextEditingController mobile = TextEditingController();
  TextEditingController bank = TextEditingController();

  String searchQuery = '';
  String bankSearchQuery = '';
  String name = '';
  String email = '';

  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    print(FirebaseAuth.instance.currentUser);
    name = FirebaseAuth.instance.currentUser!.displayName!;
    email = FirebaseAuth.instance.currentUser!.email!;
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    print(FirebaseAuth.instance.currentUser);
    return Scaffold(
      drawer: AppDrawer(userName: name, userEmail: email),
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.blue[800],
        title: Text("Fraud Rader"),
      ),
      body: Container(
        padding: const EdgeInsets.all(8.0),
        color: Colors.white,
        child: SafeArea(
          child: Column(
            children: [
              TabBar(
                labelColor: Colors.black,
                controller: _tabController,
                tabs: [
                  Tab(
                    text: 'Phone Search',
                  ),
                  Tab(text: 'Bank Account Search'),
                ],
              ),
              Expanded(
                child: TabBarView(
                  controller: _tabController,
                  children: [
                    MobileFraudScreen(),
                    BankFraudScreen(),
                    // Scaffold(
                    //   body: Stack(
                    //     children: [
                    //       Container(
                    //         padding: EdgeInsets.only(top: 75),
                    //         child: StreamBuilder(
                    //           stream: FirebaseFirestore.instance
                    //               .collection('mobile')
                    //               .where('phoneNumber', isEqualTo: searchQuery)
                    //               .snapshots(),
                    //           builder: (context,
                    //               AsyncSnapshot<QuerySnapshot> snapshot) {
                    //             if (snapshot.hasError)
                    //               return Center(
                    //                 child: Container(),
                    //               );
                    //             if (!snapshot.hasData)
                    //               return Center(
                    //                 child: CircularProgressIndicator(),
                    //               );
                    //             if (snapshot.data!.docs.isEmpty)
                    //               return Center(
                    //                 child: Text(''),
                    //               );
                    //             return ListView(
                    //               children: List.generate(
                    //                 snapshot.data!.docs.length,
                    //                 (index) => GestureDetector(
                    //                   onTap: () {
                    //                     Navigator.of(context).push(
                    //                       MaterialPageRoute(
                    //                         builder: (context) => DetailScreen(
                    //                           images: snapshot.data!.docs[index]
                    //                               ['images'],
                    //                           desc: snapshot.data!.docs[index]
                    //                               ['description'],
                    //                           fraudName: snapshot.data!
                    //                               .docs[index]['firstName'],
                    //                           WalletName: snapshot.data!
                    //                               .docs[index]['WalletName'],
                    //                           phoneNumber: snapshot.data!
                    //                               .docs[index]['phoneNumber'],
                    //                           transactionID: snapshot.data!
                    //                               .docs[index]['transactionID'],
                    //                         ),
                    //                       ),
                    //                     );
                    //                   },
                    //                   child: Container(
                    //                     margin: EdgeInsets.only(
                    //                         top: 5,
                    //                         bottom: 5,
                    //                         left: 10,
                    //                         right: 10),
                    //                     decoration: BoxDecoration(
                    //                       borderRadius:
                    //                           BorderRadius.circular(10.0),
                    //                       color: const Color(0xffffffff),
                    //                       boxShadow: [
                    //                         BoxShadow(
                    //                           color: const Color(0x29000000),
                    //                           offset: Offset(0, 3),
                    //                           blurRadius: 10,
                    //                         ),
                    //                       ],
                    //                     ),
                    //                     child: ListTile(
                    //
                    //                       title: Text(
                    //                         'Fraud Name:  ' +
                    //                             snapshot.data!.docs[index]
                    //                                 ['firstName'],
                    //                         maxLines: 1,
                    //                         style: TextStyle(fontSize: 20),
                    //                       ),
                    //
                    //                       subtitle: Text('Phone Number: '
                    //                         +snapshot.data!.docs[index]
                    //                             ['phoneNumber'],
                    //                         maxLines: 1,
                    //                         style: TextStyle(
                    //                           fontSize: 15,
                    //                         ),
                    //                       ),
                    //                     ),
                    //                   ),
                    //                 ),
                    //               ),
                    //             );
                    //           },
                    //         ),
                    //       ),
                    //       Container(
                    //         margin: EdgeInsets.only(
                    //             top: 10, right: 10, left: 10, bottom: 10),
                    //         decoration: BoxDecoration(
                    //           borderRadius: BorderRadius.circular(32),
                    //           color: Colors.white,
                    //           boxShadow: kElevationToShadow[6]!,
                    //         ),
                    //         padding: EdgeInsets.only(left: 16),
                    //         child: TextField(
                    //           onChanged: (a) {
                    //             setState(() {
                    //               searchQuery = a;
                    //             });
                    //           },
                    //           controller: mobile,
                    //           decoration: InputDecoration(
                    //               hintText: 'Search by PhoneNumber',
                    //               hintStyle: TextStyle(color: Colors.blue[300]),
                    //               border: InputBorder.none),
                    //         ),
                    //       )
                    //     ],
                    //   ),
                    //   floatingActionButton: FloatingActionButton(
                    //     backgroundColor: Colors.blue[800],
                    //     child: Icon(Icons.add),
                    //     onPressed: () {
                    //       Navigator.of(context).push(MaterialPageRoute(
                    //           builder: (context) => PhoneFraud()));
                    //     },
                    //   ),
                    // ),
                    // Scaffold(
                    //   body: Stack(
                    //     children: [
                    //       Container(
                    //         padding: EdgeInsets.only(top: 75),
                    //         child: StreamBuilder(
                    //           stream: FirebaseFirestore.instance
                    //               .collection('bank')
                    //               .where('accountNumber',
                    //                   isEqualTo: bankSearchQuery)
                    //               .snapshots(),
                    //           builder: (context,
                    //               AsyncSnapshot<QuerySnapshot> snapshot) {
                    //             if (snapshot.hasError)
                    //               return Center(
                    //                 child: Container(),
                    //               );
                    //             if (!snapshot.hasData)
                    //               return Center(
                    //                 child: CircularProgressIndicator(),
                    //               );
                    //             if (snapshot.data!.docs.isEmpty)
                    //               return Center(
                    //                 child: Text(''),
                    //               );
                    //             return ListView(
                    //               children: List.generate(
                    //                 snapshot.data!.docs.length,
                    //                 (index) => Container(
                    //                   margin: EdgeInsets.only(
                    //                       top: 5,
                    //                       bottom: 5,
                    //                       left: 10,
                    //                       right: 10),
                    //                   decoration: BoxDecoration(
                    //                     borderRadius:
                    //                         BorderRadius.circular(10.0),
                    //                     color: const Color(0xffffffff),
                    //                     boxShadow: [
                    //                       BoxShadow(
                    //                         color: const Color(0x29000000),
                    //                         offset: Offset(0, 3),
                    //                         blurRadius: 10,
                    //                       ),
                    //                     ],
                    //                   ),
                    //                   child: ListTile(
                    //                     title: Text(
                    //                       'Fraud Name:  ' +
                    //                           snapshot.data!.docs[index]
                    //                               ['fraudName'],
                    //                       maxLines: 1,
                    //                       style: TextStyle(fontSize: 20),
                    //                     ),
                    //                     subtitle: Text(
                    //                       snapshot.data!.docs[index]
                    //                           ['description'],
                    //                       maxLines: 1,
                    //                       style: TextStyle(
                    //                         fontSize: 15,
                    //                       ),
                    //                     ),
                    //                   ),
                    //                 ),
                    //               ),
                    //             );
                    //           },
                    //         ),
                    //       ),
                    //       Container(
                    //         margin: EdgeInsets.only(
                    //             top: 10, right: 10, left: 10, bottom: 10),
                    //         decoration: BoxDecoration(
                    //           borderRadius: BorderRadius.circular(32),
                    //           color: Colors.white,
                    //           boxShadow: kElevationToShadow[6]!,
                    //         ),
                    //         padding: EdgeInsets.only(left: 16),
                    //         child: TextField(
                    //           onChanged: (a) {
                    //             setState(() {
                    //               bankSearchQuery = a;
                    //             });
                    //           },
                    //           controller: bank,
                    //           decoration: InputDecoration(
                    //               hintText: 'Search',
                    //               hintStyle: TextStyle(color: Colors.blue[300]),
                    //               border: InputBorder.none),
                    //         ),
                    //       )
                    //     ],
                    //   ),
                    //   floatingActionButton: FloatingActionButton(
                    //     backgroundColor: Colors.blue[800],
                    //     child: Icon(Icons.add),
                    //     onPressed: () {
                    //       Navigator.of(context).push(MaterialPageRoute(
                    //           builder: (context) => BankFraud()));
                    //     },
                    //   ),
                    // ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
