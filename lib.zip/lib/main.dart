// import 'package:firebase_core/firebase_core.dart';
// import 'package:flutter/material.dart';
// import 'package:fraudrader/homePage.dart';
// import 'package:fraudrader/registerAct.dart';
// import 'package:provider/provider.dart';
// import 'authenticate/authenticate.dart';
// import 'models/user.dart';
// import 'services/auth.dart';
//
// void main() async {
//   WidgetsFlutterBinding.ensureInitialized();
//   //Initialize the firebase
//   await Firebase.initializeApp();
//   runApp(
//     MaterialApp(
//       debugShowCheckedModeBanner: false,
//       home: (Wrapper()),
//     ),
//   );
// }
//
// // class MyApp extends StatelessWidget {
// //   // This widget is the root of your application.
// //   @override
// //   Widget build(BuildContext context) {
// //     return MaterialApp(
// //       title: 'Flutter Demo',
// //       theme: ThemeData(
// //         primarySwatch: Colors.blue,
// //       ),
// //       home: RegisterAct(),
// //     );
// //   }
// // }
//
// class Wrapper extends StatefulWidget {
//   @override
//   _WrapperState createState() => _WrapperState();
// }
//
// class _WrapperState extends State<Wrapper> {
//   @override
//   Widget build(BuildContext context) {
//     //Get the user stream and route the user accordingly
//     return StreamProvider<LoginUser>.value(
//       value: AuthService().fireUser,
//       builder: (context, child) {
//         final loginuser = Provider.of<LoginUser>(context);
//         if (loginuser == null) {
//           //navigate to login screen if user is null
//           return Authenticate();
//         } else {
//           print(loginuser.phoneNumber);
//           if (loginuser.phoneNumber == null || loginuser.phoneNumber.isEmpty)
//             return RegisterAct();
//           return WillPopScope(
//             onWillPop: () async {
//               return false;
//             },
//             //Navigate to home screen if user is present
//             child: HomeAct(),
//           );
//         }
//       },
//       initialData: LoginUser(uid: '123', phoneNumber: '+1234567890'),
//     );
//   }
// }

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:fraudrader/homePage.dart';
import 'package:fraudrader/registerAct.dart';
import 'package:fraudrader/temp/googleSignIn.dart';
import 'package:provider/provider.dart';
import 'authenticate/authenticate.dart';
import 'models/user.dart';
import 'services/auth.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Initialize Firebase
  await Firebase.initializeApp();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: AppState(),
    );
  }
}

class AppState extends StatefulWidget {
  const AppState({Key? key}) : super(key: key);

  @override
  State<AppState> createState() => _AppStateState();
}

class _AppStateState extends State<AppState> {
  User? user ;

  @override
  void initState() {
    // TODO: implement initState
    user= FirebaseAuth.instance.currentUser;
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
   // print(user!.uid);
    return user==null ? SignUpWithGooglePage(): user!.phoneNumber==null?RegisterAct():HomeAct();
  }
}

