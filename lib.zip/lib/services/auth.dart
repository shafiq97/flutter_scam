import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart' as auth;
import 'package:fraudrader/models/user.dart';
import 'package:google_sign_in/google_sign_in.dart';

class AuthService {
  final auth.FirebaseAuth _auth = auth.FirebaseAuth.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn();

  LoginUser _userFromFirebaseUser(auth.User? user) {
    return LoginUser(
      uid: user!.uid,
      photoUrl: user.photoURL!,
      phoneNumber: user.phoneNumber!,
      displayName: user.displayName!,
    );
  }

  Stream<LoginUser> get fireUser {
    return _auth.authStateChanges().map(_userFromFirebaseUser);
  }

  //Sign in with google auth
  Future googleSignIn() async {
    final googleUser = await _googleSignIn.signIn();
    final googleAuth = await googleUser?.authentication;
    final auth.AuthCredential credential = auth.GoogleAuthProvider.credential(
      accessToken: googleAuth?.accessToken,
      idToken: googleAuth?.idToken,
    );
    final user = await _auth.signInWithCredential(credential);

    await FirebaseFirestore.instance
        .collection('users')
        .doc(user.user?.uid)
        .get()
        .then((documentSnapshot) {
      if (documentSnapshot.exists) {
      } else {
        FirebaseFirestore.instance
            .collection('users')
            .doc(user.user?.uid)
            .set({
              'uid': user.user?.uid,
              'name': user.user?.displayName,
              'phoneNumber': '',
              'email': user.user?.email,
              'photoUrl': user.user?.photoURL,
              'joiningDate': FieldValue.serverTimestamp(),
            })
            .then((value) => print('User Added'))
            .catchError((error) => print('Failed to add user: $error'));
      }
    });

    return _userFromFirebaseUser(user.user!);
  }
}
