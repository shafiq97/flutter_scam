import 'dart:io';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:auth_buttons/auth_buttons.dart';
import 'package:fraudrader/homePage.dart';
import 'package:fraudrader/services/auth.dart';
import 'package:google_sign_in/google_sign_in.dart';

import '../loading.dart';

class Authenticate extends StatefulWidget {
  @override
  _AuthenticateState createState() => _AuthenticateState();
}

class _AuthenticateState extends State<Authenticate> {
  bool loading = false;
  String error = '';
  final GoogleSignIn googleSignIn = GoogleSignIn();
  // String net = 'null';

  // @override
  // void initState() {
  //   super.initState();

  //   // checknet('in');
  // }

  // checknet(String che) async {
  //   try {
  //     final result = await InternetAddress.lookup('google.com');
  //     if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
  //       print('connected');
  //       if (che != 'in')
  //         setState(() {
  //           net = 'connected';
  //         });

  //       net = 'connected';
  //     }
  //   } on SocketException catch (_) {
  //     print('not connected');
  //     if (che != 'in')
  //       setState(() {
  //         net = 'disconnected';
  //       });

  //     net = 'connected';
  //   }
  // }

  Future<void> signInWithGoogle(BuildContext context) async {
    try {
      final GoogleSignInAccount? googleUser = await googleSignIn.signIn();
      if (googleUser == null) {
        return;
      }

      final GoogleSignInAuthentication googleAuth =
      await googleUser.authentication;

      final AuthCredential credential = GoogleAuthProvider.credential(
        idToken: googleAuth.idToken,
        accessToken: googleAuth.accessToken,
      );



    } catch (e) {
      print('Error signing in with Google: $e');
    }
  }



  @override
  Widget build(BuildContext context) {
    return loading
        ? Loading()
        : StreamBuilder(
        stream: InternetAddress.lookup('google.com').asStream(),
        builder: (context, AsyncSnapshot<List<InternetAddress>> snapshot) {
          if (!snapshot.hasData) return Container();
          if (!snapshot.data!.isNotEmpty)
            return Scaffold(
              backgroundColor: Colors.white,
              body: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'Please Turn On Data',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.w300),
                    ),
                  ],
                ),
              ),
            );
          return Container(
              color: Colors.white,
              child: Stack(children: [
                Align(
                  alignment: Alignment.topCenter,
                  child: Image.asset('images/tablet.png'),
                ),
                Align(
                    alignment: Alignment.center,
                    child: GoogleAuthButton(
                        darkMode: true,
                        onPressed: () async {
                      //    signInWithGoogle(context);

                          setState(() => loading = true);

                          final dynamic result =
                          await AuthService().googleSignIn();

                          if (result == null) {
                            setState(() {
                              error =
                              'Could not sign in with those credentials';
                              loading = false;
                            });
                          }

                        }))
              ]));
        });
  }
}
