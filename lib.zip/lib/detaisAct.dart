// import 'package:flutter/material.dart';
//
// import 'homePage.dart';
//
// class DetailsAct extends StatefulWidget {
//   @override
//   _DetailsActState createState() => _DetailsActState();
// }
//
// class _DetailsActState extends State<DetailsAct> {
//
//   final TextEditingController firstName = TextEditingController();
//   final TextEditingController lastName = TextEditingController();
//   final TextEditingController emailController = TextEditingController();
//
//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       child: Scaffold(
//         body: SafeArea(
//           child: Padding(
//             padding: const EdgeInsets.all(8.0),
//             child: Container(
//               child: Column(
//                 children: <Widget>[
//                   SizedBox(height: 18.0),
//                   Card(
//                     shape: RoundedRectangleBorder(
//                         borderRadius: BorderRadius.circular(10)),
//                     elevation: 5,
//                     child: TextField(
//                       controller: firstName,
//                       autocorrect: true,
//                       cursorColor: Colors.blue.shade800,
//                       decoration: InputDecoration(
//                         hintText: 'Firstname',
//                         prefixIcon: Icon(
//                           Icons.person,
//                           color: Colors.blue.shade800,
//                         ),
//                         hintStyle: TextStyle(color: Colors.grey),
//                         filled: true,
//                         fillColor: Colors.white70,
//                         enabledBorder: OutlineInputBorder(
//                           borderRadius:
//                           BorderRadius.all(Radius.circular(12.0)),
//                           borderSide: BorderSide(
//                               color: Colors.white, width: 2),
//                         ),
//                         focusedBorder: OutlineInputBorder(
//                           borderRadius:
//                           BorderRadius.all(Radius.circular(10.0)),
//                           borderSide: BorderSide(
//                               color: Colors.white, width: 2),
//                         ),
//                       ),
//                     ),
//                   ),
//                   SizedBox(height: 18.0),
//                   Card(
//                     shape: RoundedRectangleBorder(
//                         borderRadius: BorderRadius.circular(10)),
//                     elevation: 5,
//                     child: TextField(
//                       controller: lastName,
//                       autocorrect: true,
//                       cursorColor: Colors.blue.shade800,
//                       decoration: InputDecoration(
//                         hintText: 'lastName',
//                         prefixIcon: Icon(
//                           Icons.person,
//                           color: Colors.blue.shade800,
//                         ),
//                         hintStyle: TextStyle(color: Colors.grey),
//                         filled: true,
//                         fillColor: Colors.white70,
//                         enabledBorder: OutlineInputBorder(
//                           borderRadius:
//                           BorderRadius.all(Radius.circular(12.0)),
//                           borderSide: BorderSide(
//                               color: Colors.white, width: 2),
//                         ),
//                         focusedBorder: OutlineInputBorder(
//                           borderRadius:
//                           BorderRadius.all(Radius.circular(10.0)),
//                           borderSide: BorderSide(
//                               color: Colors.white, width: 2),
//                         ),
//                       ),
//                     ),
//                   ),
//                   SizedBox(height: 18.0),
//                   Card(
//                     shape: RoundedRectangleBorder(
//                         borderRadius: BorderRadius.circular(10)),
//                     elevation: 5,
//                     child: TextField(
//                       controller: emailController,
//                       autocorrect: true,
//                       cursorColor: Colors.blue.shade800,
//                       decoration: InputDecoration(
//                         hintText: 'email',
//                         prefixIcon: Icon(
//                           Icons.email,
//                           color: Colors.blue.shade800,
//                         ),
//                         hintStyle: TextStyle(color: Colors.grey),
//                         filled: true,
//                         fillColor: Colors.white70,
//                         enabledBorder: OutlineInputBorder(
//                           borderRadius:
//                           BorderRadius.all(Radius.circular(12.0)),
//                           borderSide: BorderSide(
//                               color: Colors.white, width: 2),
//                         ),
//                         focusedBorder: OutlineInputBorder(
//                           borderRadius:
//                           BorderRadius.all(Radius.circular(10.0)),
//                           borderSide: BorderSide(
//                               color: Colors.white, width: 2),
//                         ),
//                       ),
//                     ),
//                   ),
//                   SizedBox(height: 18.0),
//                   Container(
//                     margin: EdgeInsets.fromLTRB(0, 15, 0, 0),
//                     width: 400,
//                     child: Card(
//                       shape: RoundedRectangleBorder(
//                           borderRadius: BorderRadius.circular(20)),
//                       elevation: 5,
//                       color: Colors.blue.shade800,
//                       child: MaterialButton(
//                         onPressed: () async {
//                           //navigate to home screen
//
//                           Navigator.push(context, new MaterialPageRoute(builder: (context) => HomeAct()));
//
//                           /*final String emails = emailController.text;
//                           final String passwords = passwordController.text;
//
//                           final LoginModel logged = await userLogin(emails, passwords);
//
//                           _userLogin = logged;*/
//
//                         },
//                         child: Text(
//                           "Continue",
//                           style: TextStyle(
//                             color: Colors.white,
//                             fontSize: 20,
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }
