import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';

// class User {
//   User({
//     required this.uid,
//     required this.photoUrl,
//     required this.displayName,
//     required this.email,
//     required this.phoneNumber,
//     required this.joiningDate,
//     required this.verifiedStatus,
//     required this.emailVerified,
//   });
//   final String uid;
//   final String displayName;
//   final String phoneNumber;
//   final String email;
//   final bool emailVerified;
//   final String photoUrl;
//   final Timestamp joiningDate;
//   final bool verifiedStatus;
// }

//user model
class LoginUser {
  String uid;
  String? displayName;
  String? photoUrl;
  String? email;
  String phoneNumber;
  Timestamp? joiningDate;

  LoginUser({
   required this.uid,
    this.photoUrl,
    this.displayName,
    this.email,
   required this.phoneNumber,
    this.joiningDate,
  });
}
