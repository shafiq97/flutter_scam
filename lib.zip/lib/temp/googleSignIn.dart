import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:fraudrader/homePage.dart';
import 'package:fraudrader/registerAct.dart';
import 'package:google_sign_in/google_sign_in.dart';

class SignUpWithGooglePage extends StatefulWidget {
  @override
  _SignUpWithGooglePageState createState() => _SignUpWithGooglePageState();
}

class _SignUpWithGooglePageState extends State<SignUpWithGooglePage> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn();
  String _errorMessage = '';

  Future<UserCredential?> _signInWithGoogle() async {
    try {
      final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();
      final GoogleSignInAuthentication googleAuth =
          await googleUser!.authentication;
      final OAuthCredential credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );
      final UserCredential? user =
          await _auth.signInWithCredential(credential);


      await FirebaseFirestore.instance
          .collection('tempusers')
          .doc(user?.user?.uid)
          .set({
        'uid': user?.user?.uid,
        'name': user?.user?.displayName,
        'phoneNumber': '',
        'email': user?.user?.email,
        'photoUrl': user?.user?.photoURL,
        'joiningDate': FieldValue.serverTimestamp(),
      })
          .then((value) => print('User Added'))
          .catchError((error) => print('Failed to add user: $error'));
      return user;




    } catch (e) {
      setState(() {
        _errorMessage = 'Error signing in';
      });
      print(e.toString());
      return null;
    }
  }

  void _signOut() async {
    await _googleSignIn.signOut();
    await _auth.signOut();
  }

  void _navigateToHomePage() {
    if (FirebaseAuth.instance.currentUser!.phoneNumber != null) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => HomeAct(),
        ),
      );
    } else {
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (context) => RegisterAct()));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Sign Up with Google'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            ElevatedButton(
              onPressed: () {
                _signInWithGoogle().then((userCredential) {
                  if (userCredential != null) {
                    _navigateToHomePage();
                  }
                  else{

                  }
                });
              },
              child: Text('Sign Up with Google'),
            ),
            SizedBox(height: 20),
            Text(
              _errorMessage,
              style: TextStyle(
                color: Colors.red,
                fontSize: 16,
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _signOut,
              child: Text('Sign Out'),
            ),
          ],
        ),
      ),
    );
  }
}
//
// class HomePage extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     print(FirebaseAuth.instance.currentUser);
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Home'),
//       ),
//       body: Center(
//         child: _navigateToHomePage(),
//       ),
//     );
//   }
//
//   Widget _navigateToHomePage() {
//     if (FirebaseAuth.instance.currentUser!.phoneNumber != null) {
//       return Text('Verified');
//     } else {
//       return Text('Not verified');
//     }
//   }
// }
